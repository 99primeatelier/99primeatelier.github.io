99 PRIME ATELIER — men’s clothing storefront

WhatsApp order enquiries are configured to the business number supplied by the owner. No product prices are displayed.

To publish: upload the extracted 99_prime_atelier_store folder to a static website host. Ensure index.html and the assets folder remain together.

Note: orders open as WhatsApp message drafts; the customer must tap Send. This storefront does not process online payments.
